#ifndef PLAYER_H
#define PLAYER_H

#include <string>
#include <iostream>
using namespace std;

struct player{
	string name, position;
	float jerseyNumber, points, FGA, FGM, TPM, TPA, steals, blocks, TO, AST, REB;
  float FGP, TPP, EFGP, ATOR, REBP, TOP;
	player* next;
 };

class STATISTICS{
  private:
   int choice;
   int FGA, FGM, TPA, TPM, assists, turnovers, rebounds, steals, blocks, TO;
  public:
   void menu();
   void createPlayer(player*&);
   void deletePlayer(player*&);
   void printPlayer(player*);
   void calculatePlayer(player*);
   void printTeam(player*);
   void deleteTeam(player*&);
};
#endif