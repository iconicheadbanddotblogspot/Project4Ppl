#include "player.h"
#include <string>
#include <iostream>
#include <limits>
#include <ios>


void STATISTICS::menu(){
  
  int choice;
  player* nope= nullptr;

cout << "-----------------------------------------" << endl; 
  cout << "(1) Register Player" << endl;
  cout << "(2) Print Players" << endl;
  cout << "(3) Calculate Player Stats" << endl;
  cout << "(4) Print Whole Team and Stats" << endl;
  cout << "(5) Delete a Player" << endl;
  cout << "(6) Delete the Whole Team" << endl;
cout << "-----------------------------------------" << endl;
cout << "Selection: " << endl;

do{
  cin >> choice;
  
switch(choice){
  case 1:{
   createPlayer(nope);
   break;
}
  case 2:{
    cout << "--------------" << endl;
    printPlayer(nope);
    cout << "--------------" << endl; 
  break;
}
  case 3:{
    calculatePlayer(nope);
    break;
}
  case 4:{
    printTeam(nope);
    break;
}
  case 5:{
    deletePlayer(nope);
    break;
} 
  case 6:{
  default:
  cout << "wrong input bitch" << endl;
   }
  }
 }while (choice != 7); 
}

void STATISTICS:: createPlayer(player* &head){
  int jerseyNumber,points, FGA, FGM, TPM, TPA, steals, blocks, TO, AST;
	string name, position;
	
	cout << "Enter player's name, jersey number, and position abbreviation SEPERATED WITH A SPACE. (small forward == SF): " << endl;
	cin >> name >> jerseyNumber >> position;

  cout << "Now enter the raw stats for the player in the same fashion, seperated by a space" << endl;
  cout << "# of points, FGA, FGM, 3PA, 3PM, AST, TO, STL, and BLK in that order" << endl;
  cout << "enter a 0 for stats the player hasn't recorded pls" << endl;

  cin >> points >> FGA >> FGM >> TPA >> TPM >> AST >> TO >> steals >> blocks;

	player* current;
	player* temp = new player;
	temp->name = name;
	temp->jerseyNumber = jerseyNumber;
  temp->position = position;
  temp->points = points;
  temp->FGA = FGA;
  temp->FGM = FGM;
  temp->TPA = TPA;
  temp->TPM = TPM;
  temp->AST = AST;
  temp->TO = TO;
  temp->steals = steals;
  temp->blocks = blocks;
	temp->next = nullptr;

  if (!head) // nothing in the list
	{
		head = temp;
	}
	else // list is not empty
	{
		// Find the last node in the list.
    current = head;
		while(current->next) 
		{
			current = current->next;
		}
		// Insert newNode as the last node
		current->next = temp;
	}
}


void STATISTICS:: printPlayer(player*current){
  if(current){
    cout << "Name: " << current->name <<endl;
    cout << "Position: "  << current->position << endl;
    cout << "Jersey Number:" << current->jerseyNumber << endl;
  printPlayer(current->next); 
 }
}


void STATISTICS:: calculatePlayer(player* head){
  string name;
  player* current = head;
  player* previous = nullptr;

  cout << "Enter the name of the player you're looking for: " << endl;
  cin >> name;

  if(current){
    if(current->name == name){
      current->FGP = current->FGM / current->FGA; //calculating field goal %
      current->TPP = current->TPM / current->TPA; //calculating 3 point %
      current->ATOR = current->AST / current->TO; //calculating assist-to-turnover ratio  
    }else{
      while(current->next != nullptr && current->name != name){
         previous = current;
         current = current->next;
      }
      if(current && current->name == name){
        current->FGP = current->FGM / current->FGA; //calculating field goal %
        current->TPP = current->TPM / current->TPA; //calculating 3 point %
        current->ATOR = current->AST / current->TO; //calculating assist-to-turnover ratio 
      }
    }
  }
}


void STATISTICS:: printTeam(player* current){
 if(current){
   cout << "------------" << endl;
   cout << "Player:" << " " << current->name << "," << current->position << endl;
   cout << "Points:" << " " << current->points << endl;
   cout << "Rebounds:" << " " << current->REB << endl;
   cout << "Assists:" << " " << current->AST << endl;
   cout << "Steals:" << " " << current->steals << endl;
   cout << "Blocks:" << " " << current->blocks << endl;
   cout << "Turnovers:" << " " << current->TO << endl;
   cout << "Field Goal %:" << " " << current->FGP << endl;
   cout << "Three Point %:" << " " << current->TPP << endl;
   cout << "Assist-TO Ratio:" << " " << current->ATOR << endl;
   cout << "------------" << endl;
  printTeam(current->next);
 }
}


void STATISTICS:: deletePlayer(player* &head){
  string name;
  player* current;
  player* previous;
  current = head;
  previous = nullptr;

  cout << "Enter name of player you want to delete" << endl;
  cin >> name;

 if(current){
  if(current->name == name){
    head = current->next; // change head to the next node
    delete current;
  } else {
   while(current != nullptr && current->name != name){
     previous = current;
     current = current->next;
  }
   if(current){    //if it's not at the end of the list
     previous->next = current->next;
     delete current;
   }
  }
 }
}


void STATISTICS:: deleteTeam(player* &head){
  player* current = head;
  player* next = nullptr;
   while(current){
     next = current->next;
     delete current;
     current = next;
  }
}