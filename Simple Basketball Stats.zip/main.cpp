#include <iostream>
#include <string>
#include "player.h"
#include <fstream>
using namespace std;


int main(){
  STATISTICS fuck;
  fuck.menu();
  return 0;
}
 